<html>

<head>
<title>Redirection</title>
<!-- BEGIN HIDE -->
</head>




<script language="JavaScript" type="text/javascript">


function loadPage() {
// document.location.href = "http://dess.gl.2003.free.fr/"; 
// document.location.href = "./cours/index.php";
//  document.location.href = "./cours/student_ne.html";
 document.location.href = "./phpmyfactures"; 
}


</script>


<body onload="loadPage()">


</body>

</html>

 
