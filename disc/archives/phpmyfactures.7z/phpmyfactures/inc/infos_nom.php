<?php

/*
Informations qui seront mises sur la factures
*/

$info_nom = "Mr Gilles La Maree";
$info_adresse = "Batiment 3 grande O";
$info_code_postal = "91240 Rungis Malabry";
$info_pays = "FRANCE";

$info_banque_nom = "LCL";
$info_banque_adresse = "1 rue de la goutte d'Or";
$info_banque_ville = "PARIS";
$info_banque_code_postal = "75015";

$info_code_banque = "30003";
$info_code_guichet = "00514";
$info_code_compte = "00033514147";
$info_code_cle = "AC";
$info_code_domiciliation = "12345678945214564784123 11";

?>