</body>
</html><?php mysql_close($connect_db); ?>