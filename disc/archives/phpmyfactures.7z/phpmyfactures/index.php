<?php include("inc/conf.php"); ?>
<?php include("inc/fonctions.php"); ?>


</HEAD>



<?php include("inc/header.php"); 

?>
    </head>


<center>
Bienvenu sur Oyak!
</center>

</body>

</html>

